import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class conectarBD {
    private static final String URL = "jdbc:mariadb://localhost:3306/";
    private static final String BD = "etd";
    private static final String USER = "root";
    private static final String PASS = "";

    public static void main(String[] args) {
        try (Connection conn = DriverManager.getConnection(URL + BD, USER, PASS)) {
            if (conn != null && !conn.isClosed()) {
                System.out.println("Conectado");
            }
            
        } catch (SQLException e){
            System.out.println("Error");
            e.printStackTrace(); 
    }
}
}
