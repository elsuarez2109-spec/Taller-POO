/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package calculador;

public class otroerror {
    public static void validarEdad(int edad)throws IllegalArgumentException{
        if(edad<0||edad>150){
            throw new IllegalArgumentException("Edad no valida");
        }
    }
}
