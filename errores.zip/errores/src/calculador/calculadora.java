/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package calculador;

import javax.swing.JOptionPane;

public class calculadora {

    public static void main(String[] args) {
        try{
            int x;
            String a= JOptionPane.showInputDialog("Ingrese un valor");
            x=Integer.parseInt(a);
        }catch(Exception var1){
            JOptionPane.showMessageDialog(null, var1.getMessage());
            JOptionPane.showMessageDialog(null, var1.getStackTrace());
        }
        //otro try
        try{
            int resultado= 10/0;
            int a[]=new int[3];
            a[3]=4;
        }catch(ArithmeticException e){
            System.out.println("Error aritmetico "+ e.getMessage());
        }catch(Exception e){
            System.out.println("Error generico "+ e.getMessage());
        }finally{
            System.out.println("Limpieza completa");
        }

    }
    
}
