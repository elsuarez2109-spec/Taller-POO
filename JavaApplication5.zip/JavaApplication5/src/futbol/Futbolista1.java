
package futbol;

public class Futbolista1 extends SeleccionFutbol {
    private int dorsal;
    private String demarcacion;

    public Futbolista1(int dorsal, String demarcacion, String iniesta, int par1, int par2, String interior_Derecho) {
        this.dorsal = dorsal;
        this.demarcacion = demarcacion;
    }

    public Futbolista1(int dorsal, String demarcacion, int id, String Nombre, String Apellidos, int Edad) {
        super(id, Nombre, Apellidos, Edad);
        this.dorsal = dorsal;
        this.demarcacion = demarcacion;
    }    
    public int getDorsal() {
        return dorsal;
    }

    public void setDorsal(int dorsal) {
        this.dorsal = dorsal;
    }

    public String getDemarcacion() {
        return demarcacion;
    }

    public void setDemarcacion(String demarcacion) {
        this.demarcacion = demarcacion;
    }
    
    public void jugarPartido(){
        
    }
    public void entrenar(){
        
    }
}
