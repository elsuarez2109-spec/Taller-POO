
package futbol;

public class Entrenador extends SeleccionFutbol {
    private String idFederacion;

    public Entrenador(int id, String Nombre, String Apellidos, int Edad) {
        super(id, Nombre, Apellidos, Edad);
    }

    public String getIdFederacion() {
        return idFederacion;
    }

    public void setIdFederacion(String idFederacion) {
        this.idFederacion = idFederacion;
    }
    
}
