package futbol;
import java.util.ArrayList;

public class Principal {
    public static ArrayList<SeleccionFutbol> integrantes = new ArrayList<SeleccionFutbol>();
    public static void main(String[] args) {
	Futbolista1 iniesta = new Futbolista1(2, "Andres", "Iniesta", 29, 6, "Interior Derecho");
        integrantes.add(iniesta);
        System.out.println("Todos los integrantes comienzan una concentracion. (Todos ejecutan el mismo método)");
		for (SeleccionFutbol integrante : integrantes) {
			System.out.print(integrante.getNombre()+" "+integrante.getApellidos()+" -> ");
			integrante.Concentrarse();
	}
    }
}
