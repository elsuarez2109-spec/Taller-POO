package javaapplication5;

public class Cliente {
    
}
