
package javaapplication5;
public class Cuenta {
    private Cliente titular;
    public void ingresar(){

    }
    public void retirar(){

    }
}
