
package javaapplication5;

public class encapsular {
    private int valor=0;

    public encapsular() {
    }
    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }
    
}
