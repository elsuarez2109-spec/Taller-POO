
package javaapplication5;
import java.util.Random;

public class Principal extends encapsular {
    public static void main(String[] args) {
        Random random=new Random();
        double num= Math.random();
        int val= random.nextInt(100);
        System.out.println(num);
        System.out.println(val);
    }
    
}
