import java.util.Scanner;
class Variables{
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int opcion=0, num1=0, num2=0;
        String text="";
        boolean bool=false;
        double num3=0.0, num4=0.0;
        do{ 
            System.out.println("1. Variables integer");
            System.out.println("2. Variables double");
            System.out.println("3. Variables String");
            System.out.println("4. Variables Boolean");
            System.out.println("5. Salir");
            opcion=sc.nextInt();
            if(opcion==1){
                System.out.println("Ingrese dos numeros enteros");
                num1=sc.nextInt();
                num2=sc.nextInt();
                Metodos.Integer(num1, num2);
            }
            else if(opcion==2){
                System.out.println("Ingrese dos numeros decimales");
                num3=sc.nextDouble();
                num4=sc.nextDouble();
                Metodos.Double(num3, num4);
            }
            else if(opcion==3){
                System.out.println("Ingrese un texto");
                text=sc.next();
                Metodos.String(text);
            }
            else if(opcion==4){
                System.out.println("Ingrese un valor booleano(true/false)");
                bool=sc.nextBoolean();
                Metodos.Boolean(bool);
            }
  
        }while(opcion<5 && opcion>0);
    }
}
class Metodos{
    public static void Integer(int x,int y){
        System.out.println("La suma de dos numeros tipo integer da como resultado a otro numero integer: "+(x+y));
    }
    public static void Double(double x,double y){
        System.out.println("La suma de dos numeros tipo double da como resultado a otro numero double: "+(x+y));
    }
    public static void String(String x){
        System.out.println("El texto ingresado es: "+x);
    }
    public static void Boolean(boolean x){
        System.out.println("El valor booleano ingresado es: "+x);
    }
}