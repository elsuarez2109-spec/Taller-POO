package Punto2;
public class cita {
    public int numero,tipo;
    public double tarifa, valorFinal;

    public cita(int numero, int tipo, double tarifa, double valorFinal) {
        this.numero = numero;
        this.tipo = tipo;
        this.tarifa = tarifa;
        this.valorFinal = valorFinal;
    }
    
    public void Cita(int numero, double tarifa){
        
    }
    public int getNumero(){
        
        return 0;
    }
    public String getTipo(){
        
        return null;   
    }
    public double getTarifa(){
        
        return 0;
    }
    public double calcularValorFinal(){
        
        return 0;
    }

    public static void main(String []args){
        cita principal=new cita(11,13,12.0,9.0);
        principal.getNumero();
        principal.getTipo();
        principal.getTarifa();
        principal.getNumero();
    }
}
