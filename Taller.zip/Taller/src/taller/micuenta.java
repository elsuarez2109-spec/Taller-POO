package taller;


import java.util.Scanner;
public class micuenta {
    public static void main(String []args){
        Scanner sc=new Scanner(System.in);
        Cuenta principal=new Cuenta("Samuel",0.0);
        int opcion=0;
        do{
            System.out.println("1.Ingresar dinero \n 2.Retirar dinero \n 3. Ver datos de la cuenta \n 4.Salir \n Elija una opcion:");
            opcion=sc.nextInt();
            switch(opcion){
                    case 1:
                        System.out.println("Ingrese la cantidad que desea ingresar");
                        double ingreso=sc.nextDouble();
                        principal.ingresar(ingreso);
                        break;
                    case 2:
                        System.out.println("Ingrese la cantidad que desea retirar");
                        double retiro=sc.nextDouble();
                        principal.retirar(retiro);
                        break;
                    case 3:
                        System.out.println(principal.toString());
                        break;
                    case 4:
                        System.out.println("Saliendo de la cuenta");
                        break;
            }
        }while(opcion!=4);
    }
}
