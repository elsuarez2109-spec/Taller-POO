/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cuentaSingleton;

public class principal_cuenta {
    public static void main(String[]args){
        Cuenta singleton = Cuenta.getInstance(1000);
        Cuenta anotherSingleton = Cuenta.getInstance(500);
        System.out.println("Saldo en singleton: " + singleton.getSaldo());
        System.out.println("Saldo en anotherSingleton: " + anotherSingleton.getSaldo());
        singleton.retirar(200);
        singleton.retirar(-50);
        singleton.retirar(2000);
        System.out.println("\nSaldo final en la cuenta: " + singleton.getSaldo());
    }
}
