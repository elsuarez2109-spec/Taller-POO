/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cuenta;

public final class Cuenta {
    private static Cuenta instance;
    public double saldo;
    private Cuenta(double saldo){
        try{
            Thread.sleep(1000);
        }
        catch(InterruptedException ex){
            ex.printStackTrace();
        }
        this.saldo=saldo;
    }
    public static Cuenta getInstance(double saldo){
        if(instance==null){
            if(instance==null){
                instance=new Cuenta(saldo);
            }
        }
        return instance;
    }
    public double getSaldo(){
        return saldo;
    }
    public void depositar (double cantidad){
        if(cantidad>0){
            this.saldo+=cantidad;
        }
    }
    public boolean retirar(double cantidad) {
        if (cantidad < 0) {
            System.out.println("Error: No se puede retirar un valor negativo.");
            return false;
        }
        if (cantidad > saldo) {
            System.out.println("Error: Fondos insuficientes.");
            return false;
        }
        this.saldo -= cantidad;
        System.out.println("Nuevo saldo: " + this.saldo);
        return true;
    }
}
