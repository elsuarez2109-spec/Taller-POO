package formaPrototype;

public abstract class Forma implements Cloneable {
    private String id;
    protected String tipo;

    abstract void dibujar();

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    // Sobrescribimos el método clone
    public Object clone() {
        Object clone = null;
        try {
            clone = super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
        return clone;
    }
}

// 2. Clase concreta que extiende el prototipo
public class Circulo extends Forma {
    public Circulo() {
        tipo = "Círculo";
    }

    @Override
    public void dibujar() {
        System.out.println("Dibujando un Círculo.");
    }
}

// 3. Uso en el código cliente
public class Cliente {
    public static void main(String[] args) {
        // Objeto original (Prototipo)
        Circulo circuloOriginal = new Circulo();
        circuloOriginal.setId("1");
        
        // Clonación del objeto
        Circulo circuloClonado = (Circulo) circuloOriginal.clone();
        
        System.out.println("Tipo del clon: " + circuloClonado.tipo);
        System.out.println("Los objetos son distintos en memoria: " + (circuloOriginal != circuloClonado));
    }
}