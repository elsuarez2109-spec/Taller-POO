package vehiculos;

public abstract class Vehiculo{ //Clase abstracta y publica 

    //Miembros de la clase 
    public static final double VELOCIDAD_MAXIMA=120.0; //Variable en mayucula es una constante
    protected static final double TARIFA_BASE_PEAJE=15000.0;
    private static final int totalVehiculos=0;

    //Estado (Encapsulamiento)

    private final String placa;
    private String marca;
    private int modelo;
    private double velocidadActual;
    //Constructores (sobrecarga)
    public Vehiculo(String placa, String marca, int modelo){
        this.placa=placa;
        this.marca=marca;
        this.modelo=modelo;
        this.velocidadActual=0.0;
        totalVehiculos++;
    }
    public Vehiculo(String placa, String marca){
        this(placa, marca, 2026); //Delegacion con this
    }
    //Comportamiento
    public void acelerar(double incremento){
        if (incremento<=0){
            System.out.println(" Advertencia: El incremento debe ser un valor positivo ");
            return;
        }
        velocidadActual= Math.min(velocidadActual+incremento, VELOCIDAD_MAXIMA);
    }
    public void frenar(double decremento){
        if (decremento<=0){
            System.out.println(" Advertencia: El decremento debe ser un valor positivo ");
            return;
        }
        velocidadActual=Math.max(velocidadActual-decremento,0.0);
    }
    public void mostrarInfo(){
        System.out.println("Placa: "+placa);
        System.out.println("Marca: "+marca);
        System.out.println("Modelo: "+modelo);
        System.out.println("Velocidad Actual: "+velocidadActual+" km/h");
    }

}