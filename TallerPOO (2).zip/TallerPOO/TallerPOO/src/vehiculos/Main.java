package vehiculos;
public class Main {
    public static void main(String[] args) {
        Vehiculo v1 = new Vehiculo();
        v1.placa = "ABC123";
        v1.marca = "Renault";
        v1.modelo = 2022;
        Vehiculo v2=new Vehiculo();
        v1.placa = "XYZ789";
        v1.marca = "BMW";
        v1.modelo = 2025;
        v1.acelerar(60);
        v1.frenar(20);
        v1.mostrarInfo();
        v2.mostrarInfo();
    }
}
