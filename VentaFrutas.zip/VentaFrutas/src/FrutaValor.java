/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USER
 */
public class FrutaValor {
    String nombre;
    String color;
    double valor;

    public FrutaValor(String nombre, String color, double valor) {
        this.nombre = nombre;
        this.color = color;
        this.valor = valor;
    }

    @Override
    public String toString() {
        return "Nombre: " + nombre + " | Color: " + color + " | Valor: " + valor;
    }
}
